$().ready(function () {
    $("#firstname").click(function () {
        $("#help").text("Please type in first name in the field.")
    })
    $("#lastname").click(function () {
        $("#help").text("Please type in last name in the field.")
    })
    $("#username").click(function () {
        $("#help").text("Please type in username in the field.")
    })
    $("#address").click(function () {
        $("#help").text("Please type the addres in the field.")
    })
    $("#address2").click(function () {
        $("#help").text("Please type the address 2 in the field.")
    })
    $("#city").click(function () {
        $("#help").text("Please type in the city in the field.")
    })
    $("#state").click(function () {
        $("#help").text("Please type the state in the field.")
    })
    $("#zipCode").click(function () {
        $("#help").text("Please type in the zip code in the field.")
    })
    $("#phoneNumber").click(function () {
        $("#help").text("Please type in phone number in the field.")
    })
    $("#email").click(function () {
        $("#help").text("Please type in your email in the field.")
    })
    $("#confirmemail").click(function () {
        $("#help").text("Please retype in your email in the field.")
    })
    $("#password").click(function () {
        $("#help").text("Please type in your password in the field.")
    })
    $("#confirmpassword").click(function () {
        $("#help").text("Please retype in the password in the field.")
    })
    $("#cardnumber").click(function () {
        $("#help").text("Please type in your 16 credit card number in the field.")
    })
    $("#cardholdername").click(function () {
        $("#help").text("Please type in the card holders name in the field.")
    })
    $("#expirationyear").click(function () {
        $("#help").text("Please type in the exipiration year in the field.")
    })
    $("#expirationmonth").click(function () {
        $("#help").text("Please type in the exipiration moth in the field.")
    })
})






