$(function () {
  $("#formRegistration").validate({
    rules: {
      lastname: {
        required: true,
        minlength: 2,
      },
      firstname: {
        required: true,
        minlength: 2,
      },
      username: {
        required: true,
        minlength: 2,
      },

      address: {
        required: true
      },
      address2: {
        required: false
      },
      city: {
        required: true
      },
      state: {
        required: true
      },
      zipCode: {
        required: true,
        minlength: 5,
        maxlength: 5,
      },
      phoneNumber: {
        required: true,
        minlength: 10,
        maxlength:10
      },
      email: {
        required: true,
        email: true,
      },
      confirmemail: {
        required: true,
        email: true,
        equalTo: "#email",
      },
      password: {
        required: true,
        minlength: 5
      },
      confirmpassword: {
        required: true,
        minlength: 5,
        equalTo: "#password",
      },
      cardnumber: {
        required: true,
        minlength: 16,
        maxlength: 16,
      },
      cardholdername: {
        required: true
      },
      radioCreditCard: {
        required: true
      },
      expirationyear: {
        required: true,
        minlength: 4,
        maxlength: 4
      },
      expirationmonth: {
        required: true,
        minlength: 2,
        maxlength: 2,
      }
    },
    messages: {
      lastname: {
        required: "please enter lastname",
        minlength: "please enter atleast 2 characters",
      },
      firstname: {
        required: "please enter firstname",
        minlength: "please enter atleast 2 characters",
      },
      username: {
        required: "please enter a username",
        minlength: "please enter atleast 2 characters",
      },

      address: {
        required: "please enter a address"
      },
      address2: {
        required: "optional"
      },
      city: {
        required: "please enter a city"
      },
      state: {
        required: "please enter a state"
      },
      zipCode: {
        required: "please enter a zipcode",
        minlength: "please enter atleast 5 characters",
        maxlength: "please enter only 5 characters",
      },
      phoneNumber: {
        required: "please enter a phone number",
        minlength: "please enter atleast 10 characters",
        maxlength:" please only enter 10 characters"
      },
      email: {
        required: "please enter a email",
        email: "please enter a valid email",
      },
      confirmemail: {
        required: "please reenter a email",
        email: "please enter a valid email",
        equalTo: "emails do not match",
      },
      password: {
        required: "please enter a password",
        minlength: "please enter atleast 5 characters"
      },
      confirmpassword: {
        required: "please reenter the password",
        minlength: "please enter atleast 5 characters",
        equalTo: "passwords do not match",
      },
      cardnumber: {
        required: "please enter a credit card",
        minlength: "please enter atleast 16 characters",
        maxlength: "please enter no more 16 characters",
      },
      cardholdername: {
        required: "please enter the card holders name"
      },
      radioCreditCard: {
        required: "please select a card type"
      },
      expirationyear: {
        required: "please enter the exipration year",
        minlength: "please enter atleast 4 characters",
        maxlength: "please enter no more than 4 characters"
      },
      expirationmonth: {
        required: "please enter the exipration month",
        minlength: "please enter atleast 2 characters",
        maxlength: "please enter no more than 2 characters",
      }
    }
  });
  $(function () {
    $(document).tooltip();
  });
});