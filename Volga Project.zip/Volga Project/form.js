<!DOCTYPE html>

<html lang="en-US">
	<head>
	<meta charset ="UTF-8">
		<title>Beetle Books</title>
	<meta name="description" content="Example of meta" >
	<meta name="keywords" content="Example of meta">

<link rel="stylesheet" type="text/css" href="stylesheet.css">


</head>

<form class="cmxform" id="signupForm" method="get" action=" " autocomplete="off">

<fieldset>
	<legend> Sign-up! </legend>
<p>
	<label for="firstname">First name:</label>
          <input type="text" name="firstname" id="firstname" title="ENTER FIRST NAME" onkeyup="this.value=this.value.replace(/[^a-z]/g,'');" />
</p>


<p>
	<label for="lastname">Lastname</label> 
	<input id="lastname" name="lastname" onkeyup="this.value=this.value.replace(/[^a-z]/g,'');" type="text">
</p>


<p>
	<label for="username">Username</label>
	<input id="username" name="username" onkeyup="this.value=this.value.replace(/[^a-z0-9]/g,'');"  type="text">
</p>


<p>
	<label for="password">Password</label>
	<input id="password" name="password" type="text">
</p>


<p>
	<label for="confirmpassword">Confirm_password</label>
	<input id="confirmpassword" name="confirmpassword" type="text">
</p>

<p>
	<label for="email">Email</label>
	<input id="email" name="email" type="email">
</p>

<p>
	<label for="confirmemail">Comfirm_Email</label>
	<input id="confirmemail" name="confirmemail" type="email">
</p>


<p>
	<h1> User Information </h1>
</p>

 <p> 	<label for="phoneNumber">Number:&emsp;</label>
          <input type="text" name="phoneNumber" id="phoneNumber" title="ENTER PHONE 		NUMBER" onkeyup="this.value=this.value.replace(/[^0-9\.]/g,'');"/>

</p>

<p>	<label for="address">Address:&emsp;</label>
          <input type="text" name="address" id="address" title="ENTER ADDRESS" 			onkeyup="this.value=this.value.replace(/[^a-z0-9]/g,'');"/>
</p>

<p>        <label for="address2">Address 2:</label>
          <input type="text" name="address2" id="address2" title="OPTIONAL" 			onkeyup="this.value=this.value.replace(/[^a-z0-9]/g,'');"/>
</p>

<p>        <label for="city">City:&emsp;&emsp;&emsp;</label>
          <input type="text" name="city" id="city" title="ENTER CITY" 				onkeyup="this.value=this.value.replace(/[^a-z]/g,'');"/>
</p>

<p>        <label for="state">State:&emsp;&emsp;</label>
          <select name="state" id="state" title="ENTER STATE">
            <option value="" selected="selected">--Select a State--</option>
            <option value="AL">Alabama</option>
            <option value="AK">Alaska</option>
            <option value="AZ">Arizona</option>
            <option value="AR">Arkansas</option>
            <option value="CA">California</option>
            <option value="CO">Colorado</option>
            <option value="CT">Connecticut</option>
            <option value="DE">Delaware</option>
            <option value="DC">District Of Columbia</option>
            <option value="FL">Florida</option>
            <option value="GA">Georgia</option>
            <option value="HI">Hawaii</option>
            <option value="ID">Idaho</option>
            <option value="IL">Illinois</option>
            <option value="IN">Indiana</option>
            <option value="IA">Iowa</option>
            <option value="KS">Kansas</option>
            <option value="KY">Kentucky</option>
            <option value="LA">Louisiana</option>
            <option value="ME">Maine</option>
            <option value="MD">Maryland</option>
            <option value="MA">Massachusetts</option>
            <option value="MI">Michigan</option>
            <option value="MN">Minnesota</option>
            <option value="MS">Mississippi</option>
            <option value="MO">Missouri</option>
            <option value="MT">Montana</option>
            <option value="NE">Nebraska</option>
            <option value="NV">Nevada</option>
            <option value="NH">New Hampshire</option>
            <option value="NJ">New Jersey</option>
            <option value="NM">New Mexico</option>
            <option value="NY">New York</option>
            <option value="NC">North Carolina</option>
            <option value="ND">North Dakota</option>
            <option value="OH">Ohio</option>
            <option value="OK">Oklahoma</option>
            <option value="OR">Oregon</option>
            <option value="PA">Pennsylvania</option>
            <option value="RI">Rhode Island</option>
            <option value="SC">South Carolina</option>
            <option value="SD">South Dakota</option>
            <option value="TN">Tennessee</option>
            <option value="TX">Texas</option>
            <option value="UT">Utah</option>
            <option value="VT">Vermont</option>
            <option value="VA">Virginia</option>
            <option value="WA">Washington</option>
            <option value="WV">West Virginia</option>
            <option value="WI">Wisconsin</option>
            <option value="WY">Wyoming</option>
          </select>
</p>

<p>        <label for="zipCode">Zip code:&emsp;</label>
          <input type="text" name="zipCode" id="zipCode" title="ENTER ZIP CODE" 		onkeyup="this.value=this.value.replace(/[^0-9\.]/g,'');"/>
</p>

<p>

<h1> Billing Information</h1>
		
          <br>
<p>	<label for="cardtype">Select Cardtype:</label>
</p>
          <label for="radioCreditCard">Visa
            <input type="radio" name="radioCreditCard" id="radioCreditCard" value="visa" /></label>
          <br>
          <label for="radioCreditCard">Master Card
            <input type="radio" name="radioCreditCard" id="radioCreditCard" value="mc" /></label>
          <br>
          <label for="radioCreditCard">Discover
            <input type="radio" name="radioCreditCard" id="radioCreditCard" value="disc" /></label>
          <br>
          <label for="radioCreditCard">American Express
            <input type="radio" name="radioCreditCard" id="radioCreditCard" value="amex" /></label>

</p>

<p>
	<label for="cardnumber">Card_number</label>
	<input id="cardnumber" onkeyup="this.value=this.value.replace(/[^0-9.]/g,'');" name="cardnumber" type="text">
</p>

<p>
	<label for="cardholdername">Cardholder_name</label> 
	<input id="cardholdername" name="cardholdername" type="text" onkeyup="this.value=this.value.replace(/[^a-z]/g,'');" > 
</p>

<p>
	<label for="expirationmonth">Expirationdate_month</label>
	<input id="expirationmonth" name="expirationmonth" type="text">
</p>

<p>
	<label for="expirationyear">Expirationdate_year</label>
	<input id="expirationyear" name="expirationyear" type="text">
</p>

     	<input class="submit" type="submit" value="Submit">
        
</form>
<script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.js"></script>
<script src="Rules.js"></script>

</html>